⭐CRUDS - Bat-store

1.- Cargar la carpeta CRUDS en un IDE

2.- Crear la base de datos "bat-store" con el archivo bat-store.sql o bat-store.mwb, que esta dentro de la carpeta sql

3.- Crear un entorno virtual y activarlo

4.- Instalar pip install flet

5.- instalar pip install mysql-connector-python

6.- Dentro de src se encontrara main.py que es el archivo a compilar